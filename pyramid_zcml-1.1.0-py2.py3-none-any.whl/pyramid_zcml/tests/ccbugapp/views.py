from webob import Response

def rdf_view(request):
    """ """
    return Response('rdf')

def juri_view(request):
    """ """
    return Response('juri')

