from zope.interface import Interface

def fixture_view(context, request):
    """ """

class IDummy(Interface):
    pass

