from zope.interface import Interface

class IFixture(Interface):
    pass

def fixture():
    """ """

